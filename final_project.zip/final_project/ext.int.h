#ifndef __EXT_INT_H__
#define __EXT_INT_H__

void eint0_isr(void) __irq;

void Enable_EINT0(void);

#endif
