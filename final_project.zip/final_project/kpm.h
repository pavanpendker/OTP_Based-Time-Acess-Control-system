#include"types.h"
void Init_kpm(void);
u32 colscan(void);
u32 keyscan(void);

